package comfort.com.ua.exceptions;

public class NoSuchFurnitureException extends Exception{
    public NoSuchFurnitureException(String message)
    {
        super(message);
    }
}
