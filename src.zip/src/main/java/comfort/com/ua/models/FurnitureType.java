package comfort.com.ua.models;

public enum FurnitureType {
    CHAIR, SOFA, ARMCHAIR, CLOSET, WARDROBE, BED, TABLE, PUFF, KITCHEN
}
