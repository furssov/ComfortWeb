package comfort.com.ua.models;

public enum Priority {
    HIGH, LOW
}
