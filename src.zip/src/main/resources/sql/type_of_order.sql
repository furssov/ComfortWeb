INSERT INTO public.type_of_order (id, image, type) VALUES (1, '/images/peretyazhka.png', 'Перетяжка меблів');
INSERT INTO public.type_of_order (id, image, type) VALUES (2, '/images/korpusnaya.png', 'Корпусні меблі');
INSERT INTO public.type_of_order (id, image, type) VALUES (3, '/images/na_zakaz.png', 'М''які меблі');
