INSERT INTO public.users (id, password, role, username) VALUES (1, 'DomashiyUyut2023Artem', 'ADMIN', 'dom_uyut_admin');
